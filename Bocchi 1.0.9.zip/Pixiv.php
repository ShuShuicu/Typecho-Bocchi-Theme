<?php
/**
 * MioPixiv
 * @package custom
 * @author 鼠子(ShuShuicu)
 * @link https://blog.miomoe.cn/
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
Get::Need('header.php');
GetBocchi::Template('Pages/Pixiv');
Get::Need('footer.php');
?>