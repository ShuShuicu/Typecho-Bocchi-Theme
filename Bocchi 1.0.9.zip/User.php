<?php 
/**
 * Mio用户中心
 * @package custom
 * @author 鼠子(ShuShuicu)
 * @link https://blog.miomoe.cn/
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit; 
Get::Need('header.php');
GetBocchi::Tomori('User');
Get::Need('footer.php'); 
