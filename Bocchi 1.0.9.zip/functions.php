<?php 
/**
 * 这里是主题函数 / 功能文件。
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
// 引入框架配置文件
require_once 'Config/Config.php';
// 引入Bocchi主题功能
require_once 'Src/Functions.php';