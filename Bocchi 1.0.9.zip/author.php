<?php 
if (!defined('__TYPECHO_ROOT_DIR__')) exit; 
Get::Need('header.php');
GetBocchi::Tomori('Author');
Get::Need('footer.php'); 
